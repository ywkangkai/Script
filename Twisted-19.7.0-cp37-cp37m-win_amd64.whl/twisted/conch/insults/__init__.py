"""
Insults: a replacement for Curses/S-Lang.

Very basic at the moment."""
